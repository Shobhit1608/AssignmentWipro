import { Component } from '@angular/core';

import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-movie-list',
  imports: [MatCardModule,
    MatFormFieldModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,CommonModule],
  templateUrl: './movie-list.component.html',
  styleUrl: './movie-list.component.css'
})
export class MovieListComponent {

   genres: string[] = ['All Genres', 'Action', 'Drama', 'Sports-Drama', 'Action-Comedy'];
  selectedGenre: string = 'All Genres';

  movies = [
      { 
    title: 'Deadpool', 
    genre: 'Action-Comedy', 
    rating: 4.5, 
    description: 'A wisecracking mercenary with accelerated healing powers hunts down the man who nearly destroyed his life.', 
    image: 'https://image.tmdb.org/t/p/original/3E53WEZJqP6aM84D8CckXx4pIHw.jpg' 
  },
    { 
    title: 'Avengers: Endgame', 
    genre: 'Action', 
    rating: 4.9, 
    description: 'The Avengers assemble one final time to undo Thanos’ snap and restore balance to the universe.', 
    image: 'https://m.media-amazon.com/images/I/71+lbscQrAL._UF894,1000_QL80_.jpg' 
  },
     { 
    title: 'Attack on Titan: The Final Season', 
    genre: 'Action', 
    rating: 4.7, 
    description: 'Humanity fights for survival against titans while uncovering shocking truths about their world.', 
    image: 'https://m.media-amazon.com/images/M/MV5BNzVjOWEwYjEtNDJhOC00YjUyLThjMWItMDQwZGY1ODM4YzI3XkEyXkFqcGc@._V1_.jpg' 
  },
      { 
    title: 'Chak De! India', 
    genre: 'Sports-Drama', 
    rating: 4.7, 
    description: 'A disgraced hockey player redeems himself by coaching the Indian women’s hockey team to victory.', 
    image: 'https://resizing.flixster.com/bGe-UIhjnjCmygicDVVfK1NgiAA=/fit-in/705x460/v2/https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p168383_v_h9_ad.jpg' 
  },
    { 
    title: 'The Pursuit of Happyness', 
    genre: 'Drama', 
    rating: 4.8, 
    description: 'A struggling salesman takes custody of his son as he is about to begin a life-changing professional career.', 
    image: 'https://upload.wikimedia.org/wikipedia/en/8/81/Poster-pursuithappyness.jpg' 
  }
  ];

  get filteredMovies() {
    if (this.selectedGenre === 'All Genres') {
      return this.movies;
    }
    return this.movies.filter(movie => movie.genre === this.selectedGenre);
  }

  clearFilter() {
    this.selectedGenre = 'All Genres';
  }

  get averageRating(): number {
    const total = this.filteredMovies.reduce((sum, m) => sum + m.rating, 0);
    return this.filteredMovies.length ? total / this.filteredMovies.length : 0;
  }
}
